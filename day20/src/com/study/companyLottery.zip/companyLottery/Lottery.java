package com.study.companyLottery;

import java.util.Arrays;
import java.util.Random;

public class Lottery {

    private int id = 1;

    private int nums;


    private Random random = new Random();

    private int[] number = new int[7];

    public Lottery(int nums) {
        this.nums = nums;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNums() {
        return nums;
    }

    public void setNums(int nums) {
        this.nums = nums;
    }

    public String getNumber() {
        for (int i = 0; i < 7; i++) {
            number[i] = random.nextInt(0,32);
        }
        return Arrays.toString(number);
    }
}
