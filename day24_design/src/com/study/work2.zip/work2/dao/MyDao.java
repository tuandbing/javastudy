package com.study.work2.dao;

public interface MyDao {
    void save();
}
