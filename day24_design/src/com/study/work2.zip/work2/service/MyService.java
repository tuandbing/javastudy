package com.study.work2.service;

public interface MyService {
    void save();
}
