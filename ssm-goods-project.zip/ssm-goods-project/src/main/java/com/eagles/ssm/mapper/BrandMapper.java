package com.eagles.ssm.mapper;

import com.eagles.ssm.pojo.Brand;

import java.util.List;

public interface BrandMapper {

    List<Brand> getBrandList();

}
