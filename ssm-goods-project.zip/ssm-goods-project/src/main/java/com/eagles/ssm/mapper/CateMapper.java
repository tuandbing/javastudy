package com.eagles.ssm.mapper;

import com.eagles.ssm.pojo.Cate;

import java.util.List;

public interface CateMapper {

    List<Cate> getCateList();

}
