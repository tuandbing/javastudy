package com.eagles.ssm.service;

import com.eagles.ssm.pojo.Brand;
import com.eagles.ssm.pojo.Cate;

import java.util.List;

public interface BrandService {

    List<Brand> getBrandList();

}
