package com.eagles.ssm.service;

import com.eagles.ssm.pojo.Cate;

import java.util.List;

public interface CateService {

    List<Cate> getCateList();

}
